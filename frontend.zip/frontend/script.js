// Enhanced RAG Chatbot Frontend
class RAGChatbot {
    constructor() {
        this.apiUrl = 'http://localhost:8000';
        this.currentSessionId = 'default';
        this.searchType = 'rag';
        this.isProcessing = false;
        this.chatHistory = [];
        this.documentStats = null;
        
        this.initializeElements();
        this.setupEventListeners();
        this.checkServerStatus();
    }
    
    initializeElements() {
        // Main elements
        this.chatContainer = document.getElementById('chat-container');
        this.messageInput = document.getElementById('message-input');
        this.sendButton = document.getElementById('send-button');
        this.fileInput = document.getElementById('file-input');
        this.uploadButton = document.getElementById('upload-button');
        this.uploadArea = document.getElementById('upload-area');
        this.searchTypeSelect = document.getElementById('search-type');
        this.resetButton = document.getElementById('reset-button');
        
        // Status elements
        this.statusDiv = document.getElementById('status');
        this.statsDiv = document.getElementById('stats');
        this.filesList = document.getElementById('files-list');
        this.processingStatus = document.getElementById('processing-status');
        
        // Progress elements
        this.progressBar = document.getElementById('progress-bar');
        this.progressText = document.getElementById('progress-text');
    }
    
    setupEventListeners() {
        // Send message
        this.sendButton.addEventListener('click', () => this.sendMessage());
        this.messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        // File upload
        this.uploadButton.addEventListener('click', () => this.uploadFiles());
        this.fileInput.addEventListener('change', (e) => this.handleFileSelection(e));
        
        // Drag and drop
        this.uploadArea.addEventListener('dragover', (e) => this.handleDragOver(e));
        this.uploadArea.addEventListener('drop', (e) => this.handleDrop(e));
        this.uploadArea.addEventListener('click', () => this.fileInput.click());
        
        // Search type change
        this.searchTypeSelect.addEventListener('change', (e) => {
            this.searchType = e.target.value;
            this.updateSearchTypeInfo();
        });
        
        // Reset system
        this.resetButton.addEventListener('click', () => this.resetSystem());
        
        // Auto-resize textarea
        this.messageInput.addEventListener('input', () => this.autoResizeTextarea());
    }
    
    async checkServerStatus() {
        try {
            const response = await fetch(`${this.apiUrl}/`);
            const data = await response.json();
            
            if (data.status === 'healthy') {
                this.updateStatus('✅ Server is running', 'success');
                await this.loadSearchTypes();
                await this.loadUploadedFiles();
                await this.loadDocumentStats();
            }
        } catch (error) {
            this.updateStatus('❌ Server is offline', 'error');
            console.error('Server check failed:', error);
        }
    }
    
    async loadSearchTypes() {
        try {
            const response = await fetch(`${this.apiUrl}/search-types/`);
            const data = await response.json();
            
            // Update search type dropdown
            this.searchTypeSelect.innerHTML = '';
            data.search_types.forEach(type => {
                const option = document.createElement('option');
                option.value = type.type;
                option.textContent = type.name;
                option.title = type.description;
                this.searchTypeSelect.appendChild(option);
            });
            
            this.updateSearchTypeInfo();
        } catch (error) {
            console.error('Failed to load search types:', error);
        }
    }
    
    updateSearchTypeInfo() {
        const selectedOption = this.searchTypeSelect.selectedOptions[0];
        if (selectedOption) {
            const infoDiv = document.getElementById('search-info');
            if (infoDiv) {
                infoDiv.textContent = selectedOption.title;
            }
        }
    }
    
    handleFileSelection(event) {
        const files = Array.from(event.target.files);
        this.displaySelectedFiles(files);
    }
    
    handleDragOver(event) {
        event.preventDefault();
        this.uploadArea.classList.add('drag-over');
    }
    
    handleDrop(event) {
        event.preventDefault();
        this.uploadArea.classList.remove('drag-over');
        
        const files = Array.from(event.dataTransfer.files);
        this.fileInput.files = event.dataTransfer.files;
        this.displaySelectedFiles(files);
    }
    
    displaySelectedFiles(files) {
        const fileListDiv = document.getElementById('selected-files');
        if (!fileListDiv) return;
        
        fileListDiv.innerHTML = '';
        files.forEach(file => {
            const fileItem = document.createElement('div');
            fileItem.className = 'file-item';
            fileItem.innerHTML = `
                <span>📄 ${file.name}</span>
                <span class="file-size">${this.formatFileSize(file.size)}</span>
            `;
            fileListDiv.appendChild(fileItem);
        });
    }
    
    async uploadFiles() {
        const files = this.fileInput.files;
        if (files.length === 0) {
            this.updateStatus('❌ Please select files to upload', 'error');
            return;
        }
        
        // Check if all files are PDFs
        const invalidFiles = Array.from(files).filter(file => !file.name.endsWith('.pdf'));
        if (invalidFiles.length > 0) {
            this.updateStatus('❌ Only PDF files are allowed', 'error');
            return;
        }
        
        this.isProcessing = true;
        this.updateStatus('📤 Uploading files...', 'processing');
        this.showProgress(0, 'Uploading files...');
        
        const formData = new FormData();
        Array.from(files).forEach(file => {
            formData.append('files', file);
        });
        
        try {
            const response = await fetch(`${this.apiUrl}/upload-documents/`, {
                method: 'POST',
                body: formData
            });
            
            if (!response.ok) {
                throw new Error(`Upload failed: ${response.statusText}`);
            }
            
            const data = await response.json();
            
            this.showProgress(50, 'Processing documents...');
            
            // Poll for processing status
            await this.pollProcessingStatus();
            
            this.updateStatus('✅ Files uploaded and processed successfully', 'success');
            this.hideProgress();
            
            // Update UI
            await this.loadUploadedFiles();
            await this.loadDocumentStats();
            
            // Clear file input
            this.fileInput.value = '';
            document.getElementById('selected-files').innerHTML = '';
            
            // Show success message in chat
            this.addMessage('system', `Successfully processed ${data.files_uploaded.length} documents. You can now ask questions!`);
            
        } catch (error) {
            this.updateStatus(`❌ Upload failed: ${error.message}`, 'error');
            this.hideProgress();
            console.error('Upload error:', error);
        } finally {
            this.isProcessing = false;
        }
    }
    
    async pollProcessingStatus() {
        return new Promise((resolve) => {
            const pollInterval = setInterval(async () => {
                try {
                    const response = await fetch(`${this.apiUrl}/processing-status/`);
                    const status = await response.json();
                    
                    this.showProgress(75, status.message);
                    
                    if (status.status === 'completed' || status.status === 'error') {
                        clearInterval(pollInterval);
                        resolve(status);
                    }
                } catch (error) {
                    clearInterval(pollInterval);
                    resolve({ status: 'error', message: 'Failed to check status' });
                }
            }, 1000);
        });
    }
    
    async sendMessage() {
        const message = this.messageInput.value.trim();
        if (!message || this.isProcessing) return;
        
        // Add user message to chat
        this.addMessage('user', message);
        this.messageInput.value = '';
        this.autoResizeTextarea();
        
        // Show typing indicator
        const typingId = this.addMessage('assistant', 'Thinking...', true);
        
        try {
            const response = await fetch(`${this.apiUrl}/query/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    query: message,
                    session_id: this.currentSessionId,
                    search_type: this.searchType
                })
            });
            
            if (!response.ok) {
                throw new Error(`Query failed: ${response.statusText}`);
            }
            
            const data = await response.json();
            
            // Remove typing indicator
            this.removeMessage(typingId);
            
            // Add assistant response
            this.addMessage('assistant', data.answer, false, {
                sources: data.sources,
                processingTime: data.processing_time,
                searchType: data.search_type
            });
            
        } catch (error) {
            this.removeMessage(typingId);
            this.addMessage('assistant', `❌ Error: ${error.message}`);
            console.error('Query error:', error);
        }
    }
    
    addMessage(sender, content, isTemporary = false, metadata = null) {
        const messageId = Date.now() + Math.random();
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}-message`;
        messageDiv.dataset.messageId = messageId;
        
        let metadataHtml = '';
        if (metadata) {
            metadataHtml = `
                <div class="message-metadata">
                    <small>
                        🔍 Search: ${metadata.searchType.toUpperCase()} | 
                        ⏱️ Time: ${metadata.processingTime.toFixed(2)}s
                        ${metadata.sources && metadata.sources.length > 0 ? 
                            `| 📄 Sources: ${metadata.sources.join(', ')}` : ''}
                    </small>
                </div>
            `;
        }
        
        messageDiv.innerHTML = `
            <div class="message-content">
                <div class="message-text">${this.formatMessage(content)}</div>
                ${metadataHtml}
            </div>
        `;
        
        this.chatContainer.appendChild(messageDiv);
        this.chatContainer.scrollTop = this.chatContainer.scrollHeight;
        
        // Store in history
        if (!isTemporary) {
            this.chatHistory.push({
                id: messageId,
                sender,
                content,
                timestamp: new Date().toISOString(),
                metadata
            });
        }
        
        return messageId;
    }
    
    removeMessage(messageId) {
        const messageDiv = document.querySelector(`[data-message-id="${messageId}"]`);
        if (messageDiv) {
            messageDiv.remove();
        }
    }
    
    formatMessage(content) {
        // Convert markdown-like formatting to HTML
        return content
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/\n/g, '<br>')
            .replace(/`(.*?)`/g, '<code>$1</code>');
    }
    
    async loadUploadedFiles() {
        try {
            const response = await fetch(`${this.apiUrl}/files/`);
            const data = await response.json();
            
            this.filesList.innerHTML = '';
            
            if (data.files.length === 0) {
                this.filesList.innerHTML = '<p class="no-files">No files uploaded</p>';
                return;
            }
            
            data.files.forEach(file => {
                const fileItem = document.createElement('div');
                fileItem.className = 'file-item';
                fileItem.innerHTML = `
                    <div class="file-info">
                        <span class="file-name">📄 ${file.name}</span>
                        <span class="file-size">${file.size_mb} MB</span>
                    </div>
                    <button class="delete-btn" onclick="ragChatbot.deleteFile('${file.name}')">
                        🗑️
                    </button>
                `;
                this.filesList.appendChild(fileItem);
            });
            
        } catch (error) {
            console.error('Failed to load files:', error);
        }
    }
    
    async deleteFile(filename) {
        if (!confirm(`Are you sure you want to delete ${filename}?`)) return;
        
        try {
            const response = await fetch(`${this.apiUrl}/files/${filename}`, {
                method: 'DELETE'
            });
            
            if (!response.ok) {
                throw new Error(`Delete failed: ${response.statusText}`);
            }
            
            this.updateStatus(`✅ File ${filename} deleted`, 'success');
            await this.loadUploadedFiles();
            await this.loadDocumentStats();
            
        } catch (error) {
            this.updateStatus(`❌ Failed to delete file: ${error.message}`, 'error');
            console.error('Delete error:', error);
        }
    }
    
    async loadDocumentStats() {
        try {
            const response = await fetch(`${this.apiUrl}/stats/`);
            const data = await response.json();
            
            this.documentStats = data;
            
            this.statsDiv.innerHTML = `
                <div class="stats-grid">
                    <div class="stat-item">
                        <span class="stat-label">Documents</span>
                        <span class="stat-value">${data.total_documents}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Pages</span>
                        <span class="stat-value">${data.total_pages}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Chunks</span>
                        <span class="stat-value">${data.total_chunks}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">Processing Time</span>
                        <span class="stat-value">${data.processing_time.toFixed(2)}s</span>
                    </div>
                </div>
            `;
            
        } catch (error) {
            console.error('Failed to load stats:', error);
        }
    }
    
    async resetSystem() {
        if (!confirm('Are you sure you want to reset the system? This will delete all uploaded files and chat history.')) {
            return;
        }
        
        this.isProcessing = true;
        this.updateStatus('🔄 Resetting system...', 'processing');
        
        try {
            const response = await fetch(`${this.apiUrl}/reset/`, {
                method: 'POST'
            });
            
            if (!response.ok) {
                throw new Error(`Reset failed: ${response.statusText}`);
            }
            
            // Clear UI
            this.chatContainer.innerHTML = '';
            this.chatHistory = [];
            this.documentStats = null;
            this.fileInput.value = '';
            document.getElementById('selected-files').innerHTML = '';
            
            this.updateStatus('✅ System reset successfully', 'success');
            
            // Reload data
            await this.loadUploadedFiles();
            await this.loadDocumentStats();
            
        } catch (error) {
            this.updateStatus(`❌ Reset failed: ${error.message}`, 'error');
            console.error('Reset error:', error);
        } finally {
            this.isProcessing = false;
        }
    }
    
    updateStatus(message, type = 'info') {
        this.statusDiv.innerHTML = `<span class="status-${type}">${message}</span>`;
        
        // Auto-clear success/error messages after 5 seconds
        if (type === 'success' || type === 'error') {
            setTimeout(() => {
                if (this.statusDiv.innerHTML.includes(message)) {
                    this.statusDiv.innerHTML = '<span class="status-info">Ready</span>';
                }
            }, 5000);
        }
    }
    
    showProgress(percentage, text) {
        this.progressBar.style.width = `${percentage}%`;
        this.progressText.textContent = text;
        document.getElementById('progress-container').style.display = 'block';
    }
    
    hideProgress() {
        document.getElementById('progress-container').style.display = 'none';
    }
    
    autoResizeTextarea() {
        this.messageInput.style.height = 'auto';
        this.messageInput.style.height = Math.min(this.messageInput.scrollHeight, 120) + 'px';
    }
    
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    exportChatHistory() {
        const dataStr = JSON.stringify(this.chatHistory, null, 2);
        const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
        
        const exportFileDefaultName = `chat_history_${new Date().toISOString().split('T')[0]}.json`;
        
        const linkElement = document.createElement('a');
        linkElement.setAttribute('href', dataUri);
        linkElement.setAttribute('download', exportFileDefaultName);
        linkElement.click();
    }
    
    clearChat() {
        if (confirm('Are you sure you want to clear the chat history?')) {
            this.chatContainer.innerHTML = '';
            this.chatHistory = [];
            this.updateStatus('✅ Chat history cleared', 'success');
        }
    }
}

// Initialize the chatbot when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.ragChatbot = new RAGChatbot();
});

// Additional utility functions
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const main = document.getElementById('main-content');
    
    sidebar.classList.toggle('collapsed');
    main.classList.toggle('expanded');
}

function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    const isDark = document.body.classList.contains('dark-mode');
    localStorage.setItem('darkMode', isDark ? 'enabled' : 'disabled');
}

// Load dark mode preference
document.addEventListener('DOMContentLoaded', () => {
    const darkMode = localStorage.getItem('darkMode');
    if (darkMode === 'enabled') {
        document.body.classList.add('dark-mode');
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + K to focus on message input
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        document.getElementById('message-input').focus();
    }
    
    // Ctrl/Cmd + / to toggle sidebar
    if ((e.ctrlKey || e.metaKey) && e.key === '/') {
        e.preventDefault();
        toggleSidebar();
    }
    
    // Ctrl/Cmd + D to toggle dark mode
    if ((e.ctrlKey || e.metaKey) && e.key === 'd') {
        e.preventDefault();
        toggleDarkMode();
    }
});

// Service Worker for offline functionality (optional)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => {
                console.log('SW registered: ', registration);
            })
            .catch(registrationError => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}